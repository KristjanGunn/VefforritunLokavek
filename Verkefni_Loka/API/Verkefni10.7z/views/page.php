<!doctype html>
<html lang="is">
	<head>
		<meta charset="utf-8">
		<title>Tónleikar</title>
		<link rel="stylesheet" href="verkefni10.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width: 1500px)" href="breakpoint1500.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width: 800px)" href="breakpoint800.css">
		<link rel="stylesheet" type="text/css" media="screen and (max-width: 600px)" href="breakpoint600.css">
	</head>
	<body>
		<h1>Tónleikar</h1>
		<?php


//check if you have curl loaded
if(!function_exists("curl_init")) die("cURL extension is not installed");

$url = 'http://apis.is/concerts';

$ch=curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$r=curl_exec($ch);
curl_close($ch);

$arr = json_decode($r,true);	
		foreach($arr['results'] as $val)

		{
			echo "<div class='container'>";
			echo "<div class='Schedule'>";
			echo  "<h2>" . $val['eventDateName'] . "</h2>";
			$Timi = $val['dateOfShow'].'<br>';
			$Dagur = substr($Timi, 0, 10);
			$Klukkan = substr($Timi, 11);
			echo 'Dags: ' .$Dagur. '<br> Klukkan: '.$Klukkan.'<br>';

			if(!empty($val['name'])){
				echo $val['name'] . '<br>';
			}

			echo $val['userGroupName'].'<br>';
			echo $val['eventHallName'].'<br>';
			$a = $val['imageSource'];
			echo '<br>';
			echo "<div class='image'>";
			echo "<img src=\"".$a."\">";
			echo "</div>";
			echo '<br>';
			echo "</div>";
			echo "</div>";  
 
		}

?>		
	</body>
</html>
