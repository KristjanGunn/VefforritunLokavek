<?php
// skilum UTF-8 til vafra með header
header('Content-Type: text/html; charset=utf-8');

// krefjumst þess að hafa registration klasann
require('registration.class.php');

// hér verður haldið utan um gögn og athugað hvort gögn séu gild
$registration = new Registration();

// server superglobal er með REQUEST_METHOD sem er HTTP aðferð sem notuð var
$method = $_SERVER['REQUEST_METHOD'];

// er verið að post'a formi? Meðhöndlum þá gögn
if ($method === 'POST')
{
	$name = $_POST['name'];
	$email = $_POST['email'];
    $address  = $_POST['address'];
    $sex = $_POST['sex'];
    $spam = $_POST['spam'];
    $text = $_POST['text'];

    $errorMessage = "";
    $nameRequired = "";
    $emailRequired = "";
    $addressRequired = "";
    $genderRequired = "";


    if(empty($_POST['name'])) 
    {
    	$errorMessage .= "<li>Nafn vantar</li>";
    	$nameRequired = "Reit vantar.";
	}
	if (!preg_match("/^[a-zA-Z ]*$/",$name) && !empty($_POST['name'])) {
       	$errorMessage .= "<li>Mega bara vera stafir og bil</li>";
       	$nameRequired = "Reit vantar.";
    }


	if(empty($_POST['email'])) 
  	{
    	$errorMessage .= "<li>Vantar netfang</li>";
    	$emailRequired = "Reit vantar.";
	}

	if (!filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($_POST['email'])) {
       $errorMessage .= "<li>Vitlaust format á email addressu</li>";
       $emailRequired = "Reit vantar.";
     }

	if(empty($_POST['address'])) 
 	{
    	$errorMessage .= "<li>Vantar heimilisfang</li>";
    	$addressRequired = "Reit vantar.";
	}
	if (!preg_match("/^[A-Za-z]{1}.*\d{1}$/",$address) && !empty($_POST['address'])) {
       	$errorMessage .= "<li>Vitlaust format á heimilisfangi, þarf að vera staður svo númer</li>";
       	$addressRequired = "Reit vantar.";
    }

	if(!isset($_POST['sex'])) 
  	{
    	$errorMessage .= "<li>Vantar kyn</li>";
    	$genderRequired = "Reit vantar.";
	}

	if(!empty($errorMessage)) 
  	{	
  		echo '<div id="errors">';
   		echo("<h3>Villur komu upp: </h3>\n");
    	echo("<ul>" . $errorMessage . "</ul>\n");
    	echo '</div>'; 
  	}
  	if(empty($errorMessage)) {
  		echo '<div id="success">';
  		echo("<h3>Engar villur komu upp!</h3>");
  		echo '</div>'; 
  	}
	
	// TODO fylla $registration af gögnum
	// TODO sannreyna gögn og birta skilaboð ef OK, annars villur
}

// púslum saman viðmóti -- hér gæti þurft að hrista eitthvað upp í hlutunum
include('views/header.php');
include('views/form.php');
include('views/footer.php');