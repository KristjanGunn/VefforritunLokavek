			<h1>Skráning</h1>

			<?php
			// TODO Samantekt af villum
			// TODO Merkja input ef villur í þeim
			// TODO Klára að birta gildi aftur ef villa kom upp -- ekki tapa gögnum
			?>

			<form id="register" action="index.php" method="post">
				<div class="field">
					<label for="name">Nafn: *</label>
					<input type="text" name="name" id="name" placeholder="Jón Jóns" value="<?php echo $name; ?>" />
					<span class="error"><?php echo $nameRequired;?></span>
				</div>
				<div class="field">
					<label for="email">Netfang: *</label>
					<input type="text" name="email" id="email" placeholder="nonni@example.org" value="<?php echo $email; ?>" />
					<span class="error"><?php echo $emailRequired;?></span>
				</div>
				<div class="field">
					<label for="address">Heimilisfang: *</label>
					<input type="text" name="address" id="address" placeholder="Aðalgata 10" value="<?php echo $address; ?>" />
					<span class="error"><?php echo $addressRequired;?></span>
				</div>

				<div class="field radio">
					<span class="label">Kyn: *</span>
					<label for="kk"><input type="radio" name="sex" id="kk" value="kk" 
						<?php if (isset($sex) && $sex=="kk") echo "checked";?>
						>Karl</label>
					<label for="kvk"><input type="radio" name="sex" id="kvk" value="kvk"
						<?php if (isset($sex) && $sex=="kvk") echo "checked";?>
						>Kona</label>
					<span class="error"><?php echo $genderRequired;?></span>
				</div>

				<div class="field checkbox">
					<label for="spam"><input type="checkbox" name="spam" id="spam" value="spam" 
						<?php if (isset($spam) && $spam=="spam") echo "checked";?>
						> Sendu mér kynningar á nýju efni</label>
				</div>

				<div class="field">
					<label for="text">Athugasemd:</label>
					<textarea name="text" id="text" maxlength="100"><?php echo $text; ?></textarea>
					<div class="info">
						Hámark 100 stafir.<br>
						<div class="counter"><span id="counter"><?php echo 100-strlen(utf8_decode($text)); ?></span> eftir.</div>
					</div>
				</div>

				<div class="buttons">
					<input type="submit" value="Skrá mig">
				</div>
			</form>
